function getCalculationMetricValue() {
  var CalculationMetric = document.getElementsByName("CalculationMetric");
  for(var i in CalculationMetric) {
    if(CalculationMetric[i].checked) {
        return parseInt(i)+1;
    }
  }
  return -1;
}

function getWareHouseValue() {
  var WareHouse = document.getElementsByName("WareHouse");
  for(var i in WareHouse) {
    if(WareHouse[i].checked) {
        return parseInt(i)+1;
    }
  }
  return -1;
}

function onClickedEstimatePrice() {
  console.log("Predict Storage Weight button clicked");
  var sqft = document.getElementById("Sqft");
  var WareHouse = getWareHouseValue();
  var CalculationMetric = getCalculationMetricValue();
  var quantities = document.getElementById("Quantities");
  var estPrice = document.getElementById("EstimatedPrice");

  var url = "http://127.0.0.1:5000/estimate_weight"; 
  $.post(url, {
      totalqty_noofbags: parseFloat(sqft.value),
      Total_sqft: WareHouse,
      itemid: quantities.value
  },function(data, status) {
      console.log(data.estimated_weight);
      estPrice.innerHTML = "<h2>" + data.estimated_weight.toString() + " Kg</h2>";
      console.log(status);
  });
}


function onPageLoad() {
  console.log( "document loaded" );
  var url = "http://127.0.0.1:5000/get_quantity_names"; 
    
  $.get(url,function(data, status) {
      console.log("got response for get_quantities_names request");
      if(data) {
          var quantities = data.quantities;
          var uiquantities = document.getElementById("Quantities");
          $('#Quantities').empty();
          for(var i in quantities) {
              var opt = new Option(quantities[i]);
              $('#Quantities').append(opt);
          }
      }
  });
}

window.onload = onPageLoad;