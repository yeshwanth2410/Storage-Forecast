from flask import Flask, request, jsonify
import util

app = Flask(__name__)


@app.route('/get_quantity_names', methods=['GET'])
def get_quantity_names():
    response = jsonify({
        'quantities': util.get_quantity_names()
    })
    response.headers.add('Access-Control-Allow-Origin', '*')

    return response


@app.route('/estimate_weight', methods=['POST'])
def estimate_weight():
    totalqty_noofbags = float(request.form['totalqty_noofbags'])
    itemid = request.form['itemid']
    Total_sqft = int(request.form['Total_sqft'])

    response = jsonify({
        'estimated_weight': util.get_estimated_weight(itemid, totalqty_noofbags, Total_sqft)
    })
    response.headers.add('Access-Control-Allow-Origin', '*')

    return response


if __name__ == "__main__":
    print("Starting Python Flask Server For Storage Weight Prediction...")
    util.load_saved_artifacts()
    app.run()
