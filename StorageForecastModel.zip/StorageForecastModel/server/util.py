import pickle
import json
import numpy as np

__quantities = None
__data_columns = None
__model = None


def get_estimated_weight(itemid, totalqty_noofbags, Total_sqft):
    try:
        loc_index = __data_columns.index(itemid.lower())
    except:
        loc_index = -1

    x = np.zeros(len(__data_columns))
    x[0] = totalqty_noofbags
    x[1] = Total_sqft

    if loc_index >= 0:
        x[loc_index] = 1

    return round(__model.predict([x])[0], 2)


def get_quantity_names():
    return __quantities


def load_saved_artifacts():
    print("loading saved artifacts...start")
    global __data_columns
    global __quantities

    with open("./artifacts/columns.json", "r") as f:
        __data_columns = json.load(f)['data_columns']
        __quantities = __data_columns[3:]  # first 3 columns are sqft, bath, bhk

    global __model

    with open('./artifacts/PredictWeightStored.pickle', 'rb') as f:
        __model = pickle.load(f)
    print("loading saved artifacts...done")


if __name__ == '__main__':
    load_saved_artifacts()
    print(get_quantity_names())
    print(get_estimated_weight('Kollu 50kgs', 450, 10000.0))
    print(get_estimated_weight('Kollu 50kgs', 450, 10000.0))
    print(get_estimated_weight('Kottaipuli', 200, 4500.0))
    print(get_estimated_weight('Sarugupuli', 150, 5000.0))
